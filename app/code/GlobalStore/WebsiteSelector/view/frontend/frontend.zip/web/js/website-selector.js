/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'jquery',
    'jquery/ui'
], function ($) {
    'use strict';

    /**
     * WebsiteSelectorForm Widget - this widget is setting cookie and submitting form
     */
    $.widget('mage.websiteSelectorForm', {

        options: {
            websiteControl: '[data-role="website-selector"]',
            website_code: 'selected_website_code',
            website_code_default: 'gs_ph',
            controller_url: ''
        },

        /** @inheritdoc */
        _create: function () {
            this._bind($(this.options.websiteControl), this.options.website_code, this.options.website_code_default);
        },

        /** @inheritdoc */
        _bind: function (element, paramName, defaultValue) {
            if (element.is('select')) {
                element.on('change', {
                    paramName: paramName,
                    'default': defaultValue
                }, $.proxy(this._processSelect, this));
            }
        },

        /**
         * @param {jQuery.Event} event
         * @private
         */
        _processSelect: function (event) {
            this.changeUrl(
                event.currentTarget,
                event.data.paramName,
                event.currentTarget.options[event.currentTarget.selectedIndex].value,
                event.data.default
            );
        },

        /**
         * @param {String} paramName
         * @param {*} paramValue
         * @param {*} defaultValue
         */
        changeUrl: function (evtTarget,paramName, paramValue, defaultValue) {
          
            var websiteUrl = this.options.controller_url;
            var websiteCode = paramValue;
            
            //ajax call
            $.ajax({
                url: this.options.controller_url,
                type: 'post',
                data: {'website_code': websiteCode},
                context: evtTarget,
                beforeSend: function() {
                    $(this).prop('disabled',true);
                    // $(this).prepend("<option value='1'>Please wait...</option>").val(1);
                },
                success: function(data) {
                    location.href = data.website_url; 
                    // $(this).prepend("<option value='2'>Redirecting...</option>").val(2);
                },
                error: function(xhr,status) {
                    console.log(xhr);
                    console.log(status);
                    $(this).prop('disabled',false);
                }
            });
            
        }
    });

    return $.mage.websiteSelectorForm;
});
