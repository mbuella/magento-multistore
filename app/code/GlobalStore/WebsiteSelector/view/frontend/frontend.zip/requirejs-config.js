var config = {
    map: {
        '*': {
            websiteSelectorForm:    'GlobalStore_WebsiteSelector/js/website-selector'
        }
    }
};
